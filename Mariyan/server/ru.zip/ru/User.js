const express = require('express');
const router = express.Router();

const User = require('./../modules/Register');

router.post('/add', (req, res) => {
    const user = new User({
        Name : req.body.name,
        Email : req.body.email,
        Password : req.body.password,
        Num : req.body.num
    });

    user
    .save()
    .then(() => res.json("User Added Successfully..."))
    .catch((err) => res.json(err.message));
});

router.get('/view', (req, res) => {
    User
    .find()
    .then(response => res.json(response))
    .catch((err) => res.json(err.message));
});

router.put('/edit/:id', (req, res) => {
    User
    .findById(req.params.id)
    .then(response => {
        response.Name = req.body.name,
        response.Email =  req.body.email,
        response.Password =  req.body.password,
        response.Num =  req.body.num

        response
        .save()
        .then(() => res.json("User Updated Successfully..."))
        .catch((err) => res.json(err.message));
    })
    .catch((err) => res.json(err.message));
});

router.delete('/delete/:id', (req, res) => {
    User
    .findByIdAndDelete(req.params.id)
    .then(() => res.json("User deleted successfully..."))
    .catch((err) => resjson(err.message));
});

module.exports = router;